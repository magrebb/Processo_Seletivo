package códigos;

import java.util.Scanner;
//Autor: Arthur Souza Mendes
public class Exercicio1 {

	public static void main(String[] args) {
		
		// Criando o scanner para leitura de dados
       Scanner scanner = new Scanner(System.in);
		
		 // Solicitando a entrada de dados para usuário
        System.out.println("Digite um número para verificar se ele pertence à sequência de Fibonacci:");
        int numero = scanner.nextInt();
        
     // Chamando a função para verificar se o número pertence à sequência de Fibonacci
        if (pertenceAFibonacci(numero)) {
            System.out.println("O número " + numero + " pertence à sequência de Fibonacci.");
        } else {
            System.out.println("O número " + numero + " não pertence à sequência de Fibonacci.");
        }

        // Fechando o scanner
        scanner.close();
    }
	
	
	//Função que verifica se o número pertence à sequência de Fibonacci
    public static boolean pertenceAFibonacci(int numero) {
        if (numero == 0 || numero == 1) {
            return true;
        }

        int a = 0, b = 1;
        int proximo = a + b;

        // Gerando a sequência de Fibonacci até que o próximo valor seja maior ou igual ao número informado
        while (proximo <= numero) {
            if (proximo == numero) {
                return true;
            }
            a = b;
            b = proximo;
            proximo = a + b;
        }

        return false;
    }
}
