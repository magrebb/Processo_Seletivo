package códigos;

import java.util.Scanner;

//Autor: Arthur Souza Mendes	

public class Exercicio2 {
	
public static void main(String[] args) {
	
	        // Scanner para entrada de dados
	        Scanner scanner = new Scanner(System.in);

	        // Solicitando a entrada de dados para o usuário
	        System.out.println("Digite uma string:");
	        String texto = scanner.nextLine();
	        
	        // Convertendo a string para um array de caracteres
	        char[] caracteres = texto.toCharArray();
	        int contadorMinusculo = 0;
	        int contadorMaiusculo = 0;

	        // Percorrendo cada caractere na string
	        for (char c : caracteres) {
	            // Verificando se o caractere é 'a'
	            if (c == 'a') {
	                contadorMinusculo++;
	            }
	            // Verificando se o caractere é 'A'
	            if (c == 'A') {
	                contadorMaiusculo++;
	            }
	        }

	        // Verificando e  Exibindo a quantidade de vezes que a letra 'a' e 'A'  apareceram na String
	        if(contadorMinusculo>0|| contadorMaiusculo>0) {
	        System.out.println("A letra 'a' (minúscula) ocorre " + contadorMinusculo + " vezes.");
	        System.out.println("A letra 'A' (maiúscula) ocorre " + contadorMaiusculo + " vezes.");
	        }else
	        	System.out.println("A letra 'A' não foi utilizada.");
	        // Fechando o scanner
	        scanner.close();
	    }
	

}

