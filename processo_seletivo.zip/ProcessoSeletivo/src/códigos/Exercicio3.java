package códigos;
// Autor: Arthur Souza Mendes

public class Exercicio3 {
	public static void main(String[] args) {
	// Declaração de variáveis
	int INDICE = 12, SOMA = 0, K = 1;
	
	// Iniciando um loop que tem a incrementação da variável K
	do {  K = K + 1; SOMA = SOMA + K;
	
	
	// Fim do loop quando K alcance o valor do índice(12)
	}while( K < INDICE);
	
	// Exibindo o valor final da soma
	System.out.println("O valor final da soma é: "+SOMA);
	}

	}

	
	

